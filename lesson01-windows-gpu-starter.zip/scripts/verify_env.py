"""Lesson 01 verification. Does not install packages or require network access."""
import argparse
from datetime import datetime, timezone
import importlib
import importlib.util
import json
import platform
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CORE = ('torch', 'transformers', 'huggingface_hub', 'numpy',
        'pandas', 'matplotlib', 'ipykernel', 'accelerate', 'safetensors', 'PIL', 'packaging')
PINS = {'torch': '2.9.1+cu126', 'transformers': '5.23.0'}
MIN_CUDA_BYTES = 7500 * 1024**2


def python_errors():
    errors = []
    if sys.version_info[:2] != (3, 12):
        errors.append('Python 3.12.x is required; existing environment was not changed (manual guide 6 / 7).')
    if sys.prefix == sys.base_prefix:
        errors.append('A virtual environment is required; use the project .venv (manual guide 6 / 7).')
    return errors


def has_torchvision():
    # Never import the optional extension; broken installations can show a Windows dialog.
    return importlib.util.find_spec('torchvision') is not None


def verify_pil_processors():
    from PIL import Image
    from transformers.models.vit.image_processing_pil_vit import ViTImageProcessorPil
    from transformers.models.idefics3.image_processing_pil_idefics3 import Idefics3ImageProcessorPil

    image = Image.new('RGB', (512, 512), (80, 120, 160))
    vit = ViTImageProcessorPil(size={'height': 224, 'width': 224})
    smolvlm = Idefics3ImageProcessorPil(
        do_image_splitting=False, size={'longest_edge': 512},
        max_image_size={'longest_edge': 512},
    )
    shapes = {'vit': list(vit(images=image, return_tensors='pt')['pixel_values'].shape),
              'idefics3': list(smolvlm(images=image, return_tensors='pt')['pixel_values'].shape)}
    if shapes != {'vit': [1, 3, 224, 224], 'idefics3': [1, 1, 3, 512, 512]}:
        raise RuntimeError(f'Unexpected Pillow processor shapes: {shapes}')
    if 'torchvision' in sys.modules:
        raise RuntimeError('Pillow path unexpectedly loaded torchvision')
    return shapes


def verify(expected='cuda'):
    if expected != 'cuda':
        raise ValueError('Only the Windows CUDA profile is supported.')
    errors = python_errors()
    if platform.system() != 'Windows':
        errors.append('Windows 11 is required for this course.')
    report = {'schema_version': 3, 'profile': 'cuda-pillow', 'created_utc': datetime.now(timezone.utc).isoformat(),
              'os': platform.platform(), 'python': sys.version.split()[0],
              'architecture': platform.machine(), 'executable': sys.executable,
              'venv': sys.prefix != sys.base_prefix, 'expected_device': expected,
              'device': None, 'errors': errors}
    report['torchvision_present'] = has_torchvision()
    if report['torchvision_present']:
        errors.append('Optional torchvision detected in this course environment. Do not import it; follow the guide appendix or use a fresh course venv.')
    if errors:
        report.update(status='FAIL', runtime_ok=False, pil_ok=False)
        for error in errors:
            print(f'[FAIL] {error}')
        return report
    print('[PASS] Python 3.12 virtual environment')
    print('[PASS] cuda-pillow profile: torchvision not installed')
    modules = {}
    for name in CORE:
        try:
            module = importlib.import_module(name)
            version = getattr(module, '__version__', 'installed')
            report[name] = version
            modules[name] = module
            if name in PINS and str(version) != PINS[name]:
                raise RuntimeError(f'{PINS[name]} required, found {version}')
            print(f'[PASS] {name} {version}')
        except Exception as exc:
            errors.append(f'{name}: {type(exc).__name__}: {exc}')
    torch = modules.get('torch')
    if torch is not None:
        try:
            cuda = bool(torch.cuda.is_available())
            report.update(cuda_available=cuda, build_cuda=torch.version.cuda)
            device = 'cuda'
            report['device'] = device
            if not cuda:
                raise RuntimeError('CUDA unavailable; stop and check the project kernel, driver and CUDA wheel (manual guide 2 / 8).')
            if torch.version.cuda != '12.6':
                raise RuntimeError('CUDA 12.6 PyTorch wheel required (manual guide 8).')
            report['gpu_index'] = 0
            report['gpu_name'] = torch.cuda.get_device_name(0)
            size = torch.cuda.get_device_properties(0).total_memory
            report['vram_bytes'] = size
            report['vram_gib'] = round(size / 1024**3, 2)
            if size < MIN_CUDA_BYTES:
                raise RuntimeError('GPU 0 is below the 8GB-class minimum (7500 MiB); stop and use a qualifying NVIDIA RTX GPU.')
            torch.cuda.set_device(0)
            x = torch.arange(1, 5, dtype=torch.float32, device=device)
            result = (x * 2).cpu().tolist()
            if result != [2.0, 4.0, 6.0, 8.0]:
                raise RuntimeError(f'Unexpected tensor result: {result}')
            report['tensor_result'] = result
            report['runtime_ok'] = True
            print(f'[PASS] {device} tensor operation: {result}')
        except Exception as exc:
            report['runtime_ok'] = False
            errors.append(f'torch runtime: {type(exc).__name__}: {exc}')
    else:
        report['runtime_ok'] = False
    report['pil_ok'] = False
    if all(name in modules for name in ('torch', 'transformers', 'PIL')) and not errors:
        try:
            report['pil_shapes'] = verify_pil_processors()
            report['pil_ok'] = True
            print(f"[PASS] ViT PIL preprocessing: {report['pil_shapes']['vit']}")
            print(f"[PASS] Idefics3 PIL preprocessing: {report['pil_shapes']['idefics3']}")
        except Exception as exc:
            errors.append(f'Pillow preprocessing: {type(exc).__name__}: {exc}')
    report['status'] = 'FAIL' if errors else 'PASS'
    for error in errors:
        print(f'[FAIL] {error}')
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-device', choices=('cuda',), default='cuda')
    parser.add_argument('--check-python-only', action='store_true')
    parser.add_argument('--check-torch-profile-only', action='store_true')
    parser.add_argument('--output', type=Path, default=ROOT / 'results' / 'lesson01' / 'environment.json')
    args = parser.parse_args(argv)
    if args.check_torch_profile_only:
        try:
            if has_torchvision():
                raise RuntimeError('Optional torchvision present; follow the guide appendix or use a fresh course venv before continuing')
            torch = importlib.import_module('torch')
            if str(torch.__version__) != PINS['torch']:
                raise RuntimeError('PyTorch version mismatch')
            if torch.version.cuda != '12.6':
                raise RuntimeError('cu126 wheel required')
            print('[PASS] Installed PyTorch package profile matches')
            return 0
        except Exception as exc:
            print(f'[INFO] PyTorch package profile requires installation: {exc}')
            return 1
    if args.check_python_only:
        errors = python_errors()
        print(f'Python {sys.version.split()[0]}; venv={sys.prefix != sys.base_prefix}')
        for error in errors:
            print(f'[FAIL] {error}')
        if not errors:
            print('[PASS] Python 3.12 virtual environment')
        return 1 if errors else 0
    report = verify(args.expected_device)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_name(args.output.name + '.tmp')
    temporary.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    temporary.replace(args.output)
    print(f'[INFO] Report: {args.output}')
    if report['status'] == 'FAIL':
        print(f"[FAIL] {len(report['errors'])} checks failed")
        return 1
    label = 'CUDA'
    print(f'[PASS] Lesson 01 {label} runtime ready; VS Code Notebook execution must be checked separately.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
