# 제1교시 Starter

Windows 11 x64 · NVIDIA GPU(VRAM 8GB 이상) · PowerShell 7 · Python 3.12용 학습 자료입니다.

## 함께 사용하는 문서

- `lesson01-guidebook.md`: 단계별 설명, 실제 출력 확인 방법, 문제 해결 안내
- `lesson01-powershell-blocks.md`: 단계별로 복사·실행할 PowerShell 명령

두 문서는 이 ZIP과 별도로 제공합니다. 안내서 순서대로 한 단계씩 실행하고 결과를 확인하세요. ZIP에는 설치 스크립트나 일괄 실행 자동화를 포함하지 않습니다.

기본 프로젝트 위치: `%USERPROFILE%\AI-Engineering\modern-llm-vlm-architecture`

가이드북 4절 명령은 새 스타터를 검사한 뒤 기존 폴더가 있으면 자동으로 백업합니다. 기존 작업 영역을 닫은 뒤 실행하세요. 이전 `.venv`를 복사하지 않고 새 프로젝트에서 새 가상환경을 만듭니다.

## 포함 파일

- `.python-version`: Python 3.12 지정
- `requirements-core.txt`: 수업 패키지 목록
- `scripts/verify_env.py`: 패키지·버전·실제 CUDA 연산·두 PIL 이미지 전처리 검사 및 `results/lesson01/environment.json` 기록
- `lessons/lesson01/lesson01.ipynb`: 상세 설명, 필수 환경·GPU 확인 셀 두 개, 선택 GPT-2 설정 확인 셀 한 개
- `.vscode/settings.json`: 프로젝트 Python 환경 선택 보조 설정
- `modern-llm-vlm-architecture.code-workspace`: VS Code 프로젝트 작업 영역
- `README.md`: 자료 구성 안내

검증기 PASS는 실제 Notebook 실행을 대신하지 않습니다. Notebook에서도 CUDA와 실제 GPU 연산을 확인하세요. 장치가 `cuda`가 아니면 필수 GPU 검증은 PASS가 아닙니다. 선택 GPT-2 셀은 설정 정보만 읽으며 가중치 다운로드나 토큰 입력이 필요하지 않습니다.

## Windows CUDA 전용 실행

`verify_env.py`의 장치 옵션은 `cuda`이며, 보고서의 프로필은 `cuda-pillow`입니다. 이 과정은 torchvision을 설치하지 않습니다. CUDA·VRAM·두 PIL 전처리 검사를 모두 통과해야 환경이 준비된 것입니다.

**실행 기록 안내:** 아래 저장 출력은 이전 Windows CUDA 실행의 실제 기록입니다. 이번 수정은 CUDA를 사용할 수 없거나 VRAM이 기준에 미달하면 중단하도록 코드를 강화한 것이며, 수정 코드를 Windows GPU에서 재실행한 결과가 아닙니다. 이전 출력의 부가 진단 항목은 기록 보존을 위해 그대로 두었습니다.
